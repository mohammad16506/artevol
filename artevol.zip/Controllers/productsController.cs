﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using artevol.Models;

namespace artevol.Controllers
{
    public class productsController : Controller
    {
        private artevolEntities db = new artevolEntities();

        // GET: products
        public ActionResult Index()
        {
            var products = db.products.Include(p => p.art_type1).Include(p => p.sale_type1).Include(p => p.user);
            return View(products.ToList());
        }

        // GET: products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
			//product product = db.products.Find(id);
			var product = db.products.Include(p => p.images).SingleOrDefault(p => p.id == id);

			if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: products/Create
        public ActionResult Create()
        {
            ViewBag.art_type = new SelectList(db.art_type, "id", "type");
            ViewBag.sale_type = new SelectList(db.sale_type, "id", "sale");
            ViewBag.addedBy = new SelectList(db.users, "id", "name");
            return View();
        }

        // POST: products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,name,description,sale_type,art_type,price,addedBy")] product product, HttpPostedFileBase[] productImages )
        {
            if (ModelState.IsValid)
            {
                db.products.Add(product);
                db.SaveChanges();
                foreach (var image  in productImages)
                {
                    if(image != null && image.ContentLength > 0)
                    {
						var imageName = Path.GetFileName(image.FileName);
						var imagePath = Path.Combine(Server.MapPath("~/App_Data/images/products/"), imageName);
						image.SaveAs(imagePath);
						image dbImage = new image
						{
							prd_id = product.id,
							url = "/Images/Products/" + imageName
						};
                        db.images.Add(dbImage);
                        db.SaveChanges();

					}
				}
                return RedirectToAction("Index","product");

            }

            ViewBag.art_type = new SelectList(db.art_type, "id", "type", product.art_type);
            ViewBag.sale_type = new SelectList(db.sale_type, "id", "sale", product.sale_type);
            ViewBag.addedBy = new SelectList(db.users, "id", "name", product.addedBy);
            return View(product);
        }

        // GET: products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            product product = db.products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            ViewBag.art_type = new SelectList(db.art_type, "id", "type", product.art_type);
            ViewBag.sale_type = new SelectList(db.sale_type, "id", "sale", product.sale_type);
            ViewBag.addedBy = new SelectList(db.users, "id", "name", product.addedBy);
            return View(product);
        }

        // POST: products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,name,description,sale_type,art_type,price,addedBy")] product product)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.art_type = new SelectList(db.art_type, "id", "type", product.art_type);
            ViewBag.sale_type = new SelectList(db.sale_type, "id", "sale", product.sale_type);
            ViewBag.addedBy = new SelectList(db.users, "id", "name", product.addedBy);
            return View(product);
        }

        // GET: products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            product product = db.products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            product product = db.products.Find(id);
            db.products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
